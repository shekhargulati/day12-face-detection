

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfRect;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.highgui.Highgui;
import org.opencv.objdetect.CascadeClassifier;
 




public class FaceDetector {
 
    public static void main(String[] args) {
 
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
        System.out.println("\nRunning FaceDetector");
 
       

        
  CascadeClassifier faceDetector = new CascadeClassifier(FaceDetector.class.getResource("haarcascade_frontalface_alt.xml").getPath());
  CascadeClassifier eyesDetector = new CascadeClassifier(FaceDetector.class.getResource("haarcascade_eye.xml").getPath());
  CascadeClassifier noseDetector = new CascadeClassifier(FaceDetector.class.getResource("/haarcascade_mcs_nose.xml").getPath());
  Mat image = Highgui
              .imread(FaceDetector.class.getResource("shekhar.jpg").getPath());
  
        MatOfRect faceDetections = new MatOfRect();
        faceDetector.detectMultiScale(image, faceDetections);
 
        System.out.println(String.format("Detected %s faces", faceDetections.toArray().length));
        
        for (Rect rect : faceDetections.toArray()) {
            Core.rectangle(image, new Point(rect.x, rect.y), new Point(rect.x + rect.width, rect.y + rect.height),
                    new Scalar(0, 100, 0),3);
        }
        
        MatOfRect eyeDetections = new MatOfRect();
        eyesDetector.detectMultiScale(image, eyeDetections);
        
        for (Rect rect : eyeDetections.toArray()) {
            Core.rectangle(image, new Point(rect.x, rect.y), new Point(rect.x + rect.width, rect.y + rect.height),
                    new Scalar(200, 200, 100),2);
        }
 
         MatOfRect noseDetections = new MatOfRect();
        noseDetector.detectMultiScale(image, noseDetections);
        
        for (Rect rect : noseDetections.toArray()) {
            Core.rectangle(image, new Point(rect.x, rect.y), new Point(rect.x + rect.width, rect.y + rect.height),
                    new Scalar(50, 255, 50),2);
        }
 
        
        String filename = "output.png";
        System.out.println(String.format("Writing %s", filename));
        Highgui.imwrite(filename, image);
    }
   } 
